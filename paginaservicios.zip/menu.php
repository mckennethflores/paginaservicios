<ul class="navbar-nav">
	<li class="nav-item clinicio">
		<a class="nav-link " href="index.php">INICIO <span class="sr-only">(current)</span></a>
	</li>
	<!--    <li class="nav-item  clnosotros">
		<a class="nav-link " href="index.php#nosotros">¿Qué hacemos?</a>
	</li> -->
	<li class="nav-item">
		<a class="nav-link" href="nosotros.php">NOSOTROS</a>
	</li>

	<li class="nav-item">
		<a class="nav-link" href="servicios.php">SERVICIOS</a>
	</li>
	<!--       
	<li class="nav-item ">
		<a class="nav-link contactoquitaespacioderecho" href="productos.php">PRODUCTOS</a>
	</li> -->  		      
	<li class="nav-item ">
		<a class="nav-link contactoquitaespacioderecho" href="contacto.php">CONTÁCTO</a>
	</li>        
</ul>


