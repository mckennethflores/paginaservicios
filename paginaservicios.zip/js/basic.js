document.addEventListener('DOMContentLoaded', function() {
 

   var typed = new Typed(".anim1", {
    strings: ["carga"],
        typeSpeed: 50,
        backSpeed: 50,
         smartBackspace: true,
         bindInputFocusEvents: true,
     
     loop: true
  });

   var typed = new Typed(".anim2", {
    strings: ["distribución"],
        typeSpeed: 50,
        backSpeed: 50,
         smartBackspace: true,
         bindInputFocusEvents: true,
     
     loop: true
  });

  var typed = new Typed(".anim3", {
    strings: ["de cargas"],
        typeSpeed: 50,
        backSpeed: 50,
         smartBackspace: true,
         bindInputFocusEvents: true,
     
     loop: true
  });  
  
  var typed = new Typed(".anim4", {
    strings: ["logística"],
        typeSpeed: 50,
        backSpeed: 50,
         smartBackspace: true,
         bindInputFocusEvents: true,
     
     loop: true
  });  
  
  var typed = new Typed(".anim5", {
    strings: ["carga"],
        typeSpeed: 50,
        backSpeed: 50,
         smartBackspace: true,
         bindInputFocusEvents: true,
     
     loop: true
  });  
  
});